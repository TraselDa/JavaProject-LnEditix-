English (Australian) Dictionary for OpenOffice.org

This dictionary was based on the Australian English Dictionary 
available from http://lingucomponent.openoffice.org/spell_dic.html 
(Licensed under the LGPL.) In turn, that dictionary was based on 
the en_GB Myspell dictionary which in turn was initially based on 
a subset of the original English wordlist created by Kevin Atkinson 
for Pspell and Aspell (also initially licensed under the LGPL.) 

Cameron Roy made some improvements and packaged the improved 
dictionary for the Australian Dictionary Firefox extension. 

David Wilson packaged Cameron Roy's Firefox dictionary into this 
OpenOffice.org extension: dict-en-au.oxt. 
 
David Wilson can be contacted via email: dnwilson [at] bigpond [period] com
----------------------------------------------------------------

Copyright (C) 2006  Cameron Roy

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program (license.txt) if not, write to: 
The Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

I can be contacted via email: en-au-dictionary [at] justcameron [period] com

This dictionary was based on the Australian English Dictionary available from http://lingucomponent.openoffice.org/spell_dic.html (Licensed under the LGPL.) In turn, that dictionary was based on the en_GB Myspell dictionary which in turn was initially based on a subset of the original English wordlist created by Kevin Atkinson for Pspell and Aspell (also initially licensed under the LGPL.) 

Credit to:
Kevin Atkinson
David Bartlett 
Andrew Brown 
Kelvin Eldridge <audictionary@onlineconnections.com.au>
Brian Kelk
Jean Hollis Weber
David Wilson
